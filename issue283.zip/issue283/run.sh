#!/bin/bash

ncgen config.ncl -o config.nc

pismr \
  -boot_file boot.nc -o out.nc \
   -ys -120000 -ye -118157.6 -Mx 15 -My 30 \
  -Mz 21 -Lz 5000 -Mbz 11 -Lbz 3000 -z_spacing equal \
  -topg_to_phi 15,45,0.0,200.0 \
  -atmosphere given,lapse_rate \
  -atmosphere_given_file atm.nc -atmosphere_given_period 1 \
  -timestep_hit_multiples 1 -temp_lapse_rate 6.0 \
  -atmosphere_lapse_rate_file atm.nc \
  -surface pdd -pdd_sd_file atm.nc -pdd_sd_period 1 \
  -ocean pik -meltfactor_pik 5e-3 \
  -calving thickness_calving \
  -calving eigen_calving,thickness_calving -pik \
  -eigen_calving_K 1.0e19 -thickness_calving_threshold 200.0 \
  -thickness_calving_threshold 200.0 \
  -config_override config.nc \
  -extra_file out-extra.nc -extra_times 100 \
  -extra_vars mask,tauc,thk,topg,usurf,velbase_mag,velsurf_mag \
  &> out.txt

